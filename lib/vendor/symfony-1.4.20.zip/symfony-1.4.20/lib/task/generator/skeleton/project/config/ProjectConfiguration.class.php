<?php

require_once ##SYMFONY_CORE_AUTOLOAD##;
sfCoreAutoload::register();

class ProjectConfiguration extends sfProjectConfiguration
{
  public function setup()
  {
  }
}
