<form action="<?php echo url_for('unique/edit') ?>" method="post">
  <table>
    <?php echo $form ?>
    <tr>
      <td colspan="2">
        <input type="submit" value="submit" />
      </td>
    </tr>
  </table>
</form>
