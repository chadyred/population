<?php

/**
 * error actions.
 *
 * @package    project
 * @subpackage error
 * @author     Fabien Potencier <fabien.potencier@symfony-project.com>
 * @version    SVN: $Id: actions.class.php 5125 2007-09-16 00:53:55Z dwhittle $
 */
class errorActions extends autoerrorActions
{
}
